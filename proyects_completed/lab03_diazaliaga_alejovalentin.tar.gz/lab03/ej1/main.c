#include <stdlib.h>
#include <stdio.h>

#define MAX_SIZE 1000

unsigned int data_from_file(const char *path, unsigned int indexes[],
char letters[],unsigned int max_size) {
    FILE  *file;

    /*Abro el archivo*/
    file = fopen(path, "r");

    /*Leo y guardo la informacion*/
    unsigned int pos = 0;
    while ((pos < max_size) && (!feof(file)))
    {
        fscanf(file, "%u -> *%c*\n", &indexes[pos], &letters[pos]); 
        pos++;
    }
    
    /*Cierro el archivo*/
    fclose(file);

    /*Devuelvo la cantidad de elementos del archivo*/
    return pos;

}


static void dump(char a[], unsigned int length) {
    printf("\"");
    for (unsigned int j=0u; j < length; j++) {
        printf("%c", a[j]);
    }
    printf("\"");
    printf("\n\n");
}

int reconstruccion(unsigned int indexes[],
char letters[], char resultado[], unsigned int length, unsigned int max_size) {


    /*Asignacion de letters en resultado*/
    
    unsigned int aux;
    for (unsigned int pos = 0; pos < length; pos++)
    {
        if ((indexes[pos] < max_size) && (indexes[pos] < length))
        {
            aux = indexes[pos];
            resultado[aux] = letters[pos];
        }
    
    }

    /*Devolucion del array resultado*/
    return EXIT_SUCCESS;
} 

int main(int argc, char *argv[]) {
    
    if (argc != 2)
    {
        exit(EXIT_FAILURE);
    }
    
    /*FILE *file;*/
    unsigned int indexes[MAX_SIZE];
    char letters[MAX_SIZE];
    char sorted[MAX_SIZE];
    unsigned int length=0;
    
    length = data_from_file(argv[1], indexes, letters, MAX_SIZE);

    reconstruccion(indexes, letters , sorted, length, MAX_SIZE);    
    
    dump(sorted, length);

    return EXIT_SUCCESS;
}

