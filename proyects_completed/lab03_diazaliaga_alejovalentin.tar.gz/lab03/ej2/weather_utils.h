#include "weather.h"
#include "array_helpers.h"

int min_temp(WeatherTable);

int year_max_temp(WeatherTable array, int a[]);

int monthly_max_rainfall(WeatherTable array, unsigned int a[]);