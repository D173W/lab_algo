#include <stdio.h>
#include <stdlib.h>
#include "weather_utils.h"


int min_temp(WeatherTable array) {
    int res;
    unsigned int year;
    unsigned int month;
    unsigned int day;
    
    year = 0;
    res = 9000;
    
    while (year < YEARS)
    {
        month = 0;
        while (month < MONTHS)
        {
            day = 0;
            while (day < DAYS)
            {
                if (res > ((array[year][month][day])._min_temp))
                {
                    res = (array[year][month][day])._min_temp;
                }               
                day++;
            }
            month++;
        }
        year++;
    }
    return res;
}

int year_max_temp(WeatherTable array, int a[]){
    int res;
    unsigned int year;
    unsigned int month;
    unsigned int day;
    
    year = 0;    
    while (year < YEARS)
    {
        res = -9000; 
        month = 0;
        while (month < MONTHS)
        {
            day = 0;
            while (day < DAYS)
            {
                if (res < ((array[year][month][day])._max_temp))
                {
                    res = (array[year][month][day])._max_temp;
                }               
                day++;
            }
            month++;
        }
        a[year] = res; 
        year++;
    }

    return EXIT_SUCCESS;
}

int monthly_max_rainfall(WeatherTable array, unsigned int a[]){
    unsigned int year;
    unsigned int month;
    unsigned int day;
    unsigned int pos;
    unsigned int water;
    unsigned int mayor_mes;

    year = 0;    
    while (year < YEARS)
    {
        unsigned int aux[MONTHS];
        month = 0;

        while (month < MONTHS)
        {
            //calcula la cantidad de agua del mes
            day = 0;
            water = 0;

            while (day < DAYS)
            {
                water = water + (array[year][month][day])._rainfall;        
                day++;
            }
            
            aux[month] = water;
            month++;
        }
        
        //calculo el mes con mayor precipitacion del año
        pos = 0;
        mayor_mes = 1;
        while (pos < MONTHS)
        {
            if (aux[pos] < aux[(pos + 1)])
            {
                mayor_mes = mayor_mes + 1;
            }
            pos++;
        }
        
        //guarda el mayor mes de cada año en el arreglo respuesta
        a[year] = mayor_mes; 
        year++;
    }

    return EXIT_SUCCESS;
}