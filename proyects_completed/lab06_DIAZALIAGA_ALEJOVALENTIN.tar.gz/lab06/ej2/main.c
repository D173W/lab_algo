#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "string.h"  // Asegúrate de que este header file esté correctamente definido

int main(void) {

    string str1 = string_create("Hola");
    string str2 = string_create("Profes de lab AyEDII");
    string str3 = string_create("Hola");

    // Comparar las cadenas usando string_less
    if (string_less(str1, str2)) {
        printf("\"%s\" es menor que \"%s\"\n", string_ref(str1), string_ref(str2));
    } else {
        printf("\"%s\" no es menor que \"%s\"\n", string_ref(str1), string_ref(str2));
    }

    // Comparar las cadenas usando string_eq
    if (string_eq(str1, str3)) {
        printf("\"%s\" es igual a \"%s\"\n", string_ref(str1), string_ref(str3));
    } else {
        printf("\"%s\" no es igual a \"%s\"\n", string_ref(str1), string_ref(str3));
    }

    string_destroy(str1);
    string_destroy(str2);
    string_destroy(str3);

    return (EXIT_SUCCESS);
}
