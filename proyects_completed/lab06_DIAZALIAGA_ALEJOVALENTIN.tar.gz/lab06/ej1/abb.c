#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include "abb.h"

struct _s_abb {
    abb_elem elem;
    struct _s_abb *left;
    struct _s_abb *right;
};

/*
static bool elem_eq(abb_elem a, abb_elem b) {
    return a == b;
}

static bool elem_less(abb_elem a, abb_elem b) {
    return a < b;
}
*/
static bool invrep(abb tree) {
    bool b;

    if (abb_is_empty(tree)) {
        b = true;
    } 
    else {
        b = (abb_is_empty(tree->left) || (tree->elem > tree->left->elem && invrep(tree->left))) &&
            (abb_is_empty(tree->right) || (tree->elem < tree->right->elem && invrep(tree->right)));
    }

    return b;
}

abb abb_empty(void) {
    abb tree = NULL;
    assert(invrep(tree) && abb_is_empty(tree));
    return tree;
}

abb abb_add(abb tree, abb_elem e) {
    assert(invrep(tree));
    
    if (!abb_exists(tree, e)) {
        if (abb_is_empty(tree)) {
            tree = malloc(sizeof(*tree));
            assert(tree != NULL);
            tree->elem = e;
            tree->left = NULL;
            tree->right = NULL;
        } else {
            if (tree->elem > e) {
                tree->left = abb_add(tree->left, e);
            } else {
                tree->right = abb_add(tree->right, e);
            }
        }
    }
    
    assert(invrep(tree) && abb_exists(tree, e));
    return tree;
}

bool abb_is_empty(abb tree) {
    return tree == NULL;
}

bool abb_exists(abb tree, abb_elem e) {
    bool exists=false;
    assert(invrep(tree));
    
    if(!abb_is_empty(tree)){
        if(tree->elem == e){
            exists = true;
        }
        else{
            exists = abb_exists(tree->right, e) || abb_exists(tree->left, e);
        }
    }

    assert(abb_length(tree)!=0 || !exists);
    return exists;
}

unsigned int abb_length(abb tree) {
    unsigned int length=0;
    assert(invrep(tree));
    
    if(!abb_is_empty(tree)){
        length = 1 + abb_length(tree->right) + abb_length(tree->left); 
    }
    
    assert(invrep(tree) && (abb_is_empty(tree) || length > 0));
    return length;
}

abb abb_remove(abb tree, abb_elem e) {
    assert(invrep(tree));

    if(abb_exists(tree, e)){
        if(tree->elem < e){
            tree->right = abb_remove(tree->right, e);
        }
        else if(tree->elem > e){
            tree->left = abb_remove(tree->left, e);
        }
        else{
            /*En este caso, encontramos el nodo a eliminar*/
            /*Subdividimos en casos mas simples*/

            if(abb_is_empty(tree->right) && abb_is_empty(tree->left)){
                // si no tiene hijos, lo eliminamos directamente
                free(tree);
                tree = NULL;
            }
            else if(abb_is_empty(tree->right)){
                // si solo tiene elementos a la izquierda
                abb temp = tree;
                tree = tree->left;
                free(temp);
                temp = NULL;
            }
            else if(abb_is_empty(tree->left)){
                // si solo tiene elementos a la derecha
                abb temp = tree;
                tree = tree->right;
                free(temp);
                temp = NULL;
            }
            else{
                // tiene elementos en ambos lados
                /*
                Podemos encontrar el minimo del lado derecho, lo cual significa que reducimos el problema
                al caso de solo lados a la derecha.
                Podriamos hacer lo mismo buscando el maximo del lado izquierdo.
                */
                
                /* Encontramos el minimo */
                abb_elem min = abb_min(tree->right);
                
                /* Una vez que encontramos el minimo, lo reemplazamos en el nodo "a eliminar" */
                tree->elem = min;
                
                /* Ahora solo queda eliminar el nodo que contenia al minimo, actualizando la rama derecha */
                tree->right = abb_remove(tree->right, min);
            }
        }
    }

    assert(invrep(tree) && !abb_exists(tree, e));
    return tree;
}


abb_elem abb_root(abb tree) {
    abb_elem root;
    assert(invrep(tree) && !abb_is_empty(tree));
    
    root = tree->elem;
    
    assert(invrep(tree) && abb_exists(tree, root));
    return root;
}

abb_elem abb_max(abb tree) {
    abb_elem max_e;
    assert(invrep(tree) && !abb_is_empty(tree));
    
    if(!abb_is_empty(tree->right)){
        max_e = abb_max(tree->right);
    }
    else{
        max_e = tree->elem;
    }

    assert(invrep(tree) && abb_exists(tree, max_e));
    return max_e;
}

abb_elem abb_min(abb tree) {
    abb_elem min_e;
    assert(invrep(tree) && !abb_is_empty(tree));
    
    if(!abb_is_empty(tree->left)){
        min_e = abb_min(tree->left);
    }
    else{
        min_e = tree->elem;
    }

    assert(invrep(tree) && abb_exists(tree, min_e));
    return min_e;
}

void abb_dump(abb tree, abb_ordtype ord) {
    assert(invrep(tree) && (ord==ABB_IN_ORDER  || 
                            ord==ABB_PRE_ORDER ||
                            ord==ABB_POST_ORDER));
    
    if (tree != NULL && ord == ABB_IN_ORDER) {
        abb_dump(tree->left, ord);
        printf("%d ", tree->elem);
        abb_dump(tree->right, ord);
    }
    else if (tree != NULL && ord == ABB_PRE_ORDER) {
        printf("%d ", tree->elem);
        abb_dump(tree->left, ord);
        abb_dump(tree->right, ord);
    }
    else if (tree != NULL && ord == ABB_POST_ORDER) {
        abb_dump(tree->left, ord);
        abb_dump(tree->right, ord);
        printf("%d ", tree->elem);
    }
}

abb abb_destroy(abb tree) {
    assert(invrep(tree));
    
    if(!abb_is_empty(tree)){
        tree->left = abb_destroy(tree->left);
        tree->right = abb_destroy(tree->right);
        free(tree);
        tree = NULL;
    }

    assert(tree == NULL);
    return tree;
}