#include <stdbool.h>
#include <assert.h>

#include "fixstring.h"


unsigned int fstring_length(fixstring s) {
    unsigned int pos;
    pos = 0;
    while (s[pos] != '\0' && pos < FIXSTRING_MAX)
    {
        pos = pos + 1;
    }
    return pos;
    
}

bool fstring_eq(fixstring s1, fixstring s2) {
bool res;
    unsigned int pos;
    res = true;
    pos = 0;
    if (fstring_length(s1) != fstring_length(s2))
    {
        res = false;
    }
    while (pos < fstring_length(s1))
    {
        if (s1[pos] != s2[pos])
        {
            res = false;
        }
        pos = pos + 1;
    }
    return res;
}

bool fstring_less_eq(fixstring s1, fixstring s2) {
    bool res;
    unsigned int pos;
    res = true;
    pos = 0;

    while ((s1[pos] == s2[pos]) && !((s1[pos] == '\0') || (s2[pos] == '\0'))) {
        pos++;
    }
    if (s1[pos] > s2[pos])
    {
        res = false;
    }
    return res; 
}

