#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

void absolute(int x, int *y) {
    if (x >= 0)
    {
        *y = x;
    }
    else 
    {
        *y = -(x);
    }
}

int main(void) {
    int a=-10, res=0;  // No modificar esta declaración
    // --- No se deben declarar variables nuevas ---

    absolute(a, &res);
    printf("%d\n", res);
    assert(res >= 0 && (res == a || res == -a));
    return EXIT_SUCCESS;
}

// El parametro int *y de absolute() es de tipo out ya que solo se lo sobrescribe.

// C tiene disponible los tipos de parámetros IN, OUT y IN/OUT