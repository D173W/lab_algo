#ifndef _LIST_H
#define _LIST_H

#include <stdbool.h>

typedef int list_elem;
typedef struct _list * list;


list empty(void);

list addl(list x, list_elem e);

void destroy_list(list x);

list copy_list(list x);

bool is_empty(list x);

//PRE: not is_empty
list_elem head(list x);
//PRE: not is_empty
list_elem tailist(list x);

list addr(list x, list_elem e);

unsigned int lengthlist(list x);

list concat(list x, list y);

//PRE: length() > n
list_elem index(list x, unsigned int);

list take(list x, unsigned int n);

list drop(list x, unsigned int n);


#endif