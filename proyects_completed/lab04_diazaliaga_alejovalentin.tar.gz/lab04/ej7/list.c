#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "list.h"

struct _list {
    list_elem value;
    list next;
};

list empty(void){
    list res = NULL;
    return res;
}

list addl(list x, list_elem e){
    list aux = malloc(sizeof(struct _list));

    if (is_empty(x))
    {
        aux->next = NULL;
        aux->value = e;
        (x) = aux;
    }
    else
    {   
        aux->next = x;
        aux->value = e;
        x = aux;
    }
    
    return x;
}

void destroy_list(list x){
    while (x != NULL)
    {
        list temp = x;
        x = x->next;
        free(temp);
    }
}

list copy_list(list x){
    list nueva = empty();
    if (is_empty(x))
    {
        return nueva;
    }
    else {
        list aux = x;
        while (aux->next != NULL)
        {
            addr(nueva, aux->value);
            aux = (aux->next);
        }
        return nueva;
    }
}

bool is_empty(list x){
    bool res = (x == NULL);
    return res;
}

//PRE: not is_empty
list_elem head(list x){
    assert(!(is_empty(x)));
    return (x->value);
}
//PRE: not is_empty
list_elem tailist(list x){
    assert(!(is_empty(x)));
    list_elem res;
    struct _list aux = *x;
    while ((aux.next) != NULL)
    {
        aux = *aux.next;
    }
    res = aux.value;
    return res;
}

list addr(list x, list_elem e){
    list aux = malloc(sizeof(struct _list));
    aux->next = NULL;
    aux->value = e;

    if (is_empty(x))
    {
        return addl(x, e);
    }
    
    else {
        list pos = x;
        while (pos->next != NULL)
        {
            pos = pos->next;
        }
        
        pos->next = aux;
        return x;
    }
}

unsigned int lengthlist(list x){
    unsigned int res;
    if (is_empty(x)){
        res = 0;
    }
    else 
    {
        res = 1;
        struct _list aux;
        aux = *x;
        while (aux.next != NULL)
        {
            aux = *aux.next;
            res++;
        }
    }

    return res;
}

list concat(list x, list y){
    if (is_empty(x) && !(is_empty(y)))
    {
        return y;
    }
    if (is_empty(y) && !(is_empty(x)))
    {
        return x;
    }
    else
    {
        struct _list aux = *x;
        while (aux.next != NULL)
            {
                aux = *aux.next;
            }
        aux.next = copy_list(y);
        return x;
    }
}

//PRE: length() >= n 
list_elem index(list x, unsigned int n){
    assert(lengthlist(x) >= n);
    unsigned int pos = 1;
    struct _list aux = *x;
    while (pos <  n && aux.next != NULL)
    {
        aux = *aux.next;
        pos++;
    }    
    return aux.value;
}

list take(list x, unsigned int n){
    if (is_empty(x))
    {
        return x;
    }
    else
    {
        struct _list aux = *x;
        while (n > 1 && aux.next != NULL )
        {
            aux = *aux.next;
            n = n-1;
        }
        if (aux.next == NULL)
        {
            return x;
        }
        else {
            destroy_list(aux.next);
            return x;
        }
    }
}

list drop(list x, unsigned int n){
    if (is_empty(x))
    {
        return x;
    }
    else
    {
        struct _list aux = *x;
        while (n > 1 || aux.next != NULL)
        {
            aux = *aux.next;
            n = n-1;
        }
        destroy_list(aux.next);
        return x;
    }
}
