#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "pair.h"


struct s_pair_t {
    elem fst;
    elem snd;
};

pair_t pair_new(elem x, elem y){
    pair_t res = malloc(sizeof(pair_t));
    res->fst = x;
    res->snd = y;
    return res;
}

elem pair_first(pair_t p){
    return p->fst;
}

elem pair_second(pair_t p){
    return p->snd;
}

pair_t pair_swapped(pair_t p){
    pair_t res = pair_new(pair_second(p), pair_first(p));
    return res;
}

pair_t pair_destroy(pair_t p){
    free(p);
    p = NULL;
    return p;
}

// la diferencia que hay es que ahora es cuasi polimorfico, es cuestion de modoficar el tipo en el struct de arriba. 