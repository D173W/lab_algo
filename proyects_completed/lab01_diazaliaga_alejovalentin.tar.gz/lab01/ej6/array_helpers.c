#include "array_helpers.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

unsigned int array_from_file(int array[],
                             unsigned int max_size,
                             const char *filepath) {
    unsigned int res;
    int aux;
    FILE * file;
    file = fopen(filepath, "r");

    fscanf(file, "%u", &res);
    if (res > max_size)
    {
        res = max_size;
    }

    for (unsigned int pos = 0; pos < res; pos++)
    {
        fscanf(file, "%d", &aux);
        array[pos] = aux;
    }
    fclose(file);
    return res;
}

void array_dump(int a[], unsigned int length) {
    unsigned int pos = 0;
    printf("[ ");
    while (pos < (length - 1))
    {
        printf("%d, ", a[pos]);
        pos = pos + 1;
    }
    printf("%d]", a[pos]);    
}

bool array_is_sorted(int a[], unsigned int length) {
    bool res;
    res = true;
    for (unsigned int pos = 0; (pos < (length - 1)) && (res); pos++)
    {
        res = res && (a[pos] < a[pos + 1]);
    }
    return res;   
}

void array_swap(int a[], unsigned int i, unsigned int j) {
    int temp;
    temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}