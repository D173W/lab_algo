#include <stdlib.h>
#include <assert.h>
#include "stack.h"

struct _s_stack {
    stack_elem *elems;      // Arreglo de elementos
    unsigned int size;      // Cantidad de elementos en la pila
    unsigned int capacity;  // Capacidad actual del arreglo elems
};

stack stack_empty() {
    stack s = malloc(sizeof(struct _s_stack));
    if (s == NULL)
    {
        printf("la memoria se asigno incorrectamente");
    }

    s->capacity = 5;
    s->size = 0;
    s->elems = calloc(s->capacity, sizeof(stack_elem));

    return s;
}

stack stack_push(stack s, stack_elem e){
    assert(s->size <= s->capacity); // INV: la cantidad de elementos en la pila es <= que su capacidad
    if (s->size == s->capacity)
    {
        s->capacity = s->capacity * 2;
        s->elems = realloc(s->elems, s->capacity);
    }

    s->elems[s->size - 1] = e;
    s->size = s->size + 1; // sumo uno al tamaño de la pila
    return s;
}

stack stack_pop(stack s){
    s->elems[s->size - 1] = 0;
    s->size = s->size - 1; // resto uno al tamaño de la pila
    return s;
}

unsigned int stack_size(stack s){
    return s->size;
}

stack_elem stack_top(stack s){
    return s->elems[s->size - 1];
}

bool stack_is_empty(stack s){
    bool res = s->size == 0;
    return res;
}

stack_elem *stack_to_array(stack s){
    return s->elems;
}

stack stack_destroy(stack s){
    free(s->elems);
    s->size = 0;
    return s;
}
