#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "stack.h"

struct _node {
    stack_elem elem;
    struct _node *next;
};


struct _s_stack {
    struct _node *first_pointer;
    unsigned int length;
};

stack stack_empty(){
    stack s = malloc(sizeof(struct _s_stack)); 
    s->first_pointer = NULL;
    s->length = 0;
    return s;
}

stack stack_push(stack s, stack_elem e){
    struct _node *new = NULL;
    new = malloc(sizeof(struct _node));

    new->elem = e;
    new->next = (s->first_pointer);
    s->first_pointer = new;
    s->length = s->length + 1;

    return s;
}

stack stack_pop(stack s){
    assert(s->first_pointer != NULL);
    struct _node *next = (s->first_pointer);
    s->first_pointer = s->first_pointer->next;
    free(next);
    s->length = s->length - 1;
    return s;
}

unsigned int stack_size(stack s){
    return s->length;
}

stack_elem stack_top(stack s){
    assert(s->first_pointer != NULL);

    stack_elem res;
    res = s->first_pointer->elem;
    
    return res;
}

bool stack_is_empty(stack s){
    bool res = (stack_size(s) == 0);
    return res;
}

stack_elem *stack_to_array(stack s){
    stack_elem *array_res = NULL;
    

    if (!stack_is_empty(s))
    {
        struct _node *pos = s->first_pointer;
        unsigned int size = stack_size(s);
        array_res = calloc(size, sizeof(*array_res));

        if (array_res == NULL) {
            printf("error al asignar memoria\n");
        }

        unsigned int i = size - 1;
        while(pos != NULL){
            array_res[i] = pos->elem;
            pos = pos->next;
            i--;
        }    
    }
    
    return array_res;
}

void stack_destroy(stack s){
    
    while(!stack_is_empty(s)){
        stack_pop(s);
    }
    free(s);
}