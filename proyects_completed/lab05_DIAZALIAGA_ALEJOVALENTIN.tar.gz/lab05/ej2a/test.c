#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "stack.h"

int main()
{
    // pilas de 1 elem
    
    
    stack new = NULL;
    new = stack_empty();
    
    new = stack_push(new, 7);
    new = stack_pop(new);

    if (stack_is_empty(new))
    {
        printf("stack_pop anda bien con pilas de 1 elem\n");
    }
    
    new = stack_push(new, 7);

    if (stack_top(new) == 7)
    {
        printf("si puedo volver a insertar elementos luego de vaciar una pila \n");
    }

    new = stack_pop(new);

    stack_elem* arreglo = stack_to_array(new);

    if (arreglo == NULL) {
        printf("el stack to array si devuelve null p. una pila vacia \n");
    }

    new = stack_empty();

    stack_elem* arreglo_dos = NULL;
    arreglo_dos =  stack_to_array(new);

    if (arreglo_dos == NULL)
    {
        printf("todo joya pa");
    }
    
    //printf("el size de arreglo dos es: %d", &stack_size(arreglo_dos));
    //printf(" los valores del arreglo son: %d, %d, %d \n", arreglo_dos[0], arreglo_dos[1], arreglo_dos[2]);
    
    free(arreglo_dos);

    return 0;
}
