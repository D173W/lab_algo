#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "stack.h"
 

struct _s_stack {
    stack_elem elem;
    stack next;
};

stack stack_empty(){
    stack res = NULL;
    return res;
}

stack stack_push(stack s, stack_elem e){
    stack new = NULL;
    new = malloc(sizeof(struct _s_stack));
    new->elem = e;
    new->next = s;

    return new;
}

stack stack_pop(stack s){
    assert(s != NULL);
    stack aux = NULL;
    aux = s;
    s = s->next;

    free(aux);
    return s;
}

unsigned int stack_size(stack s){
    unsigned int res = 0;
    stack aux = s;

    while (aux != NULL)
    {
        ++res;
        aux = aux->next;
    }

    return res;
}

stack_elem stack_top(stack s){
    assert(s != NULL);

    stack_elem res;
    res = s->elem;
    
    return res;
}

bool stack_is_empty(stack s){
    bool res = false;

    if (s == NULL)
    {
        res = true;
    }
    
    return res;
}

stack_elem *stack_to_array(stack s){
    stack_elem *array_res = NULL;
    

    if (!stack_is_empty(s))
    {
        stack pos = s;
        unsigned int size = stack_size(s);
        array_res = calloc(size, sizeof(*array_res));

        if (array_res == NULL) {
            printf("error al asignar memoria\n");
        }

        unsigned int i = size - 1;
        while(pos != NULL){
            array_res[i] = pos->elem;
            pos = pos->next;
            i--;
        }    
    }
    
    return array_res;
}

stack stack_destroy(stack s){
    stack current = s;
    stack next = s->next;
    
    while(s != NULL){
        next = current->next;
        free(current);
        current = next;
    }

    return s;
}