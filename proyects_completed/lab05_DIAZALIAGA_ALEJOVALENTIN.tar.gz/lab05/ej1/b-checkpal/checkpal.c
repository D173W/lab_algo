#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "strfuncs.h"

#define MAX_LENGTH 20

#define SIZEOF_ARRAY(s) (sizeof(s) / sizeof(*s))

int main(void) {
    char user_input[MAX_LENGTH];
    char user_input_aux[MAX_LENGTH];
    char ignore_chars[] = {' ', '?', '!', ',', '-', '.'};
    char *filtered=NULL;

    printf("Ingrese un texto (no más de %d símbolos) para verificar palíndromo: ", MAX_LENGTH);
    fgets(user_input_aux, MAX_LENGTH, stdin);

    unsigned int length = string_length(user_input_aux);
    unsigned int pos = 0;
    unsigned int load_pos = 0;

    while (pos <= length)
    {
        if (user_input_aux[pos] != '\n') 
        {
            user_input[load_pos] = user_input_aux[pos];
            pos++;
            load_pos++;
        }
        else {
            pos = pos + 2;
        }
    }
    

    filtered = user_input;
    for (unsigned int i=0; i < SIZEOF_ARRAY(ignore_chars); i++) {
        
        filtered = string_filter(filtered, ignore_chars[i]);
        free(filtered);
    }

    printf("El texto:\n\n"
            "\"%s\" \n\n"   
            "%s un palíndromo.\n\n", user_input, string_is_symmetric(filtered) ? "Es": "NO es");

    return EXIT_SUCCESS;
}

//los problemas generados por scanf() son que no puedo agarrar palabras y no frases