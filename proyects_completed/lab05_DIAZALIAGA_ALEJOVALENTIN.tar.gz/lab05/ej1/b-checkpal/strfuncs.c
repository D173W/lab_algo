#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "strfuncs.h"

size_t string_length(const char *str){
    unsigned int counter = 0;
    

    if (str == NULL){} // Caso en que la string es vacia 
    else { // Caso en que la string NO es vacia
        unsigned int pos = 0;

        while (str[pos] != '\0')
        {
            counter++;
            pos++;
        }
    }
    
    return counter;
}

char *string_filter(const char *str, char c){
    char *res = NULL;

    if (str == NULL) {} // Caso en que la string es vacia

    else { // Caso en que la string es NO vacia


        //Averiguo de que tamaño será el RESULTADO
        unsigned int iguales_a_c = 0;
        unsigned int pos = 0;
        while (str[pos] != '\0')
        {
            if (str[pos] == c)
            {
                iguales_a_c++;
            }
            pos++;
        }
        
        //Calculo el tamaño de RES: tamaño de str - iguales a c + 1 para '\o'
        res = malloc(sizeof(char)*(string_length(str) + 1 - iguales_a_c));

        //Cargo la string apuntada por res con los caracteres diferentes a c
        pos = 0;
        unsigned int load_pos = 0;
        while (str[pos] != '\0')
        {
            if (str[pos] != c)
            {
                res[load_pos] = str[pos];
                
                load_pos++;
                pos++;
            }
            else {
                pos++;
            }
        }
        
        //Cargo el caracter para dar final a la nueva string
        res[load_pos] = '\0';
    }

    return res;
}

bool string_is_symmetric(const char *str){
    bool res = true;
    unsigned int length = string_length(str);
    
    // Caso: STRING VACIA
    if (length == 0) {}

    // Caso: STRING con un caracter
    else if (length == 1) {} 
    
    // Caso: STRING con 2 o mas caracteres
    else 
    { 
        unsigned int pos = 0;
        while (pos < ((length / 2)) && res)
        {
            if (str[pos] == str[length - pos - 1])
            {
                pos++;
            }
            else {
                res = false;
            }
        }
        
    }
    
    return res;
}